#!/bin/bash

gcc -O2 $1.c -o $1
